package songsDAC;

public class DACTester {
	
	public static void main(String [] args) {
		Song song = new Song("1");
		System.out.println(song.title);
	}
	
}
