package songsDAC;

public class DBInfo {
	public static String DBFILEPATH = System.getProperty("user.dir") + "\\database";
	public static String DB_NAME = "Songs_Data_Source.db";
}